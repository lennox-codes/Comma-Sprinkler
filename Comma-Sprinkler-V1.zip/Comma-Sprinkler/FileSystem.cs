﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Comma_Sprinkler
{
    internal class FileSystem
    {
        VM vm = VM.Instance;

        public OpenFileDialog ofd = new OpenFileDialog()
        {
            //InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Examples),
            Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*",
            FilterIndex = 2,
            Multiselect = false
        };

        public void AssignAndCalcInput()
        {
            if (ofd.ShowDialog() == true)
            {
                //string filepath = ofd.FileName;
                vm.FileName = ofd.FileName;

                string textInput = File.ReadAllText(vm.FileName);               
                vm.SprinkleComma(textInput);
            }               
        }
    }
}
