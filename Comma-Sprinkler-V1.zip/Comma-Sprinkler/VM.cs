﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Comma_Sprinkler
{
    internal class VM : INotifyPropertyChanged
    {
        readonly List<string> wordsWithPreceedingCommas = new List<string>();
        readonly List<string> wordsWithSucceedingCommas = new List<string>();

        #region Singleton
        private static VM vm;
        public static VM Instance
        {
            get
            {
                vm ??= null;
                return new VM();
            }
        }
        
        private VM()
        {
        }
        #endregion

        #region Properties
        private string textInput;
        public string TextInput
        {
            get { return textInput; }
            set { textInput = value; notifyChange(); }
        }

        private string output;

        public string Output
        {
            get { return output; }
            set { output = value; notifyChange(); }
        }

        private string fileName;

        public string FileName
        {
            get { return fileName; }
            set { fileName = value; notifyChange(); }
        }
        #endregion

        #region Methods
        public string SprinkleComma(string input)
        {
            string[] sentences = input.Split(new string[] { ". ", "." }, StringSplitOptions.RemoveEmptyEntries);
            string currentInput;
            string previousInput = input;

            foreach (string sentence in sentences)
            {
                PopulateRulesWordList(sentence);
            }

            foreach (string foundWord in wordsWithSucceedingCommas)
            {
                for (int i = 0; i < sentences.Length; i++)
                {
                    string[] words = sentences[i].Split(new char[] { ' ' });
                    string[] newSentence = ApplyIfWordSucceededByComma(words, foundWord);
                    sentences[i] = String.Join(" ", newSentence);
                }
            }

            foreach (string foundWord in wordsWithPreceedingCommas)
            {
                for (int i = 0; i < sentences.Length; i++)
                {
                    string[] words = sentences[i].Split(new char[] { ' ' });
                    string[] newSentence = ApplyIfWordPreceededByComma(words, foundWord);
                    sentences[i] = String.Join(" ", newSentence);
                }
            }
            
            currentInput = String.Join(". ", sentences) + ".";

            //This recursively calls the function by comparing the current and previous inputs.
            if (currentInput != previousInput)
                return SprinkleComma(currentInput);
            else
            {
                wordsWithPreceedingCommas.Clear();
                wordsWithSucceedingCommas.Clear();
                return Output = currentInput;
            }
        }

        //This checks to see if the word has a succeeding comma or not
        private bool HasSucceedingComma(string word)
        {
            return word.EndsWith(",");
        }

        //This removes the last char of the textInput;
        private string RemoveLastChar(string input)
        {
            input = input.Remove(input.Length - 1, 1);
            return input;
        }

        //If the foundword is the last word of the sentence, nothing happens,
        //Otherwise, if the word doesn't already contain a comma, you apply a comma in front of it.
        private string[] ApplyIfWordSucceededByComma(string[] words, string foundWord)
        {
            for (int i = 0; i < words.Length - 1; i++)
            {               
                string currentWord = words[i];

                //No need to check for comma, because if the currentWord contains a comma, this function doesn't run.
                if (foundWord == currentWord && i != words.Length - 1)
                {
                    words[i] = currentWord + ",";
                }
                
            }
              
            return words;               
        }

        //If the foundWord is the firstWord of the sentence, nothing happens.
        //Otherwise, if the word doesn't contain a comma already and is succeeded by the foundWord, you apply a comma infront of the word.
        private string[] ApplyIfWordPreceededByComma(string[] words, string foundWord)
        {
            string firstWord = words[0];

            for (int i = 1; i < words.Length ; i++)
            {
                string currentWord = words[i];
                string previousWord = words[i - 1];

                //The current word could have a comma or not in front of it but that shouldn't matter in this scenario.
                if (!HasSucceedingComma(previousWord) && (currentWord == foundWord || currentWord == foundWord + ","))
                {
                    words[i - 1] = previousWord + ",";
                }           
            }

            //This step is crucial because it checks to see if the firstWord initially had a comma in front of it or not
            if (words[1] == foundWord  && !HasSucceedingComma(firstWord))
            {
                words[0] = firstWord  + ",";
            }

            return words;          
        }

        //This populates the wordsRulesList by just looking through words preceeded or succeeded by commas.
        private void PopulateRulesWordList(string sentence)
        {
            if (sentence.Contains(','))
            {
                string[] words = sentence.Split(new char[] { ' ' });

                for (int i = 0; i < words.Length - 1; i++) 
                {
                    string word = words[i];
                    string nextWord = words[i + 1];

                    if (HasSucceedingComma(word))
                    {
                        if (!wordsWithSucceedingCommas.Contains(RemoveLastChar(word)))
                            wordsWithSucceedingCommas.Add(RemoveLastChar(word));

                        if (!wordsWithPreceedingCommas.Contains(nextWord))
                            wordsWithPreceedingCommas.Add(nextWord);
                    }
                }
            }
        }
        #endregion

        #region Property Changed
        public event PropertyChangedEventHandler PropertyChanged;

        private void notifyChange([CallerMemberName] string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        #endregion
    }
}
